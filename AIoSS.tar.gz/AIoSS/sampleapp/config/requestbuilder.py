'''File to store HTTP configurations'''

import credentials
import base64

PORT = 443
REQUEST_HEADERS = {
'Content-Type':'application/json', 
'Authorization' : 'Basic ' + base64.b64encode(bytes(credentials.MARKETPLACE_ID + ':' + credentials.SECRET))
}

MULTIPART_HEADERS = {
'Authorization' : 'Basic ' + base64.b64encode(bytes(credentials.MARKETPLACE_ID + ':' + credentials.SECRET))
}

def create_request(end_point):
    request = REQUEST_URL = credentials.HOST_URL + credentials.API_VERSION + end_point
    return request
    
