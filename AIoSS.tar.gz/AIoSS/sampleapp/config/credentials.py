'''File to store openchannel.io API credentials'''

HOST_URL = 'https://market.openchannel.io/'
API_VERSION = 'v2'
MARKETPLACE_ID = '5adcfefffd67b67d3fb1bfd7'
SECRET = 'EIi8i2sglN_oIfzcPy6gtkCW-EGq-rqBe13COMkFOA0'
DEVELOPER_ID = '1'
USER_ID = '1'
