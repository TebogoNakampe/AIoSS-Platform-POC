from django.conf.urls import include, url
from . import views

urlpatterns = [
    url(r'^$', views.market_home),
    url(r'^details/(?P<app_id>.*)/(?P<version>.*)/$', views.app_detail),
    url(r'^details/(?P<safe_name>.*)/$', views.app_details),
    url(r'^apps/$', views.list_apps),
    url(r'^apps/search/$', views.app_search),
    url(r'^apps/category/$', views.app_category),
    url(r'^apps/manage_app/$', views.manage_app),
    url(r'^apps/related_apps/$', views.related_apps),
    url(r'^apps/create/$', views.create_app),
    url(r'^apps/(?P<app_id>.*)/(?P<version>.*)/publish/$', views.publish_app),
    url(r'^apps/edit/(?P<app_id>.*)/(?P<version>.*)/$', views.update_app),
    url(r'^apps/(?P<app_id>.*)/(?P<version>.*)/delete/$', views.delete_app),
    url(r'^apps/(?P<app_id>.*)/delete/$', views.delete_app),
    url(r'^apps/upload/$', views.upload_file),
    url(r'^apps/(?P<app_id>.*)/(?P<status>.*)/suspend/$', views.suspend_app),
]
