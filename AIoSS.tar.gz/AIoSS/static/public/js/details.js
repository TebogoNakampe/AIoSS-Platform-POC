$(document).ready(function() {


embededvideo = $(".embed-responsive-item")[0];
if(embededvideo != undefined){
	videoUrl = embededvideo.getAttribute("src")
	if(getEmbedVideoCode(videoUrl) == ""){
		var video = '<a class="video-button btn btn-default" style="margin-top: 59px; margin-left:56px; padding-left:62px; padding-right:57px" href="//'+videoUrl+'" target="_blank">Video</a>';
		$(".embed-responsive").html(video)
	}
}

});